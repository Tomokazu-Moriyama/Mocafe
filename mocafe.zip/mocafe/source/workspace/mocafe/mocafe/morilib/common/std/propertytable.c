/* Parts of The Mocafe (C language morilib library).
 * Copyright (C) 2016 Tomokazu Moriyama.
 *
 * This program is free software; you can redistribute it and/or modify 
 * it under the terms of the GNU Lesser General Public License as published by 
 * the Free Software Foundation; either version 3 of the License, or 
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, 
 * but WITHOUT ANY WARRANTY; without even the implied warranty of 
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 * See the GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License 
 * along with this program; see the file COPYING.LESSER.
 * if not see <http://www.gnu.org/licenses/>.
 * if not, write to the Free Software Foundation, Inc., 
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

/** 
 * C language collection framework library.
 * Properties table.
 * 
 * @Auther Tomokazu Moriyama (�X�R�F�a)
 * @Version 0.0.1
 */

/*
 * ���C�u�������F �v���p�e�B�e�[�u��
 *
 * Date				author				Changes
 * ????/??/??		�X�R �F�a		�V�K�쐬
 * 2006/05/04		�X�R �F�a		����
 * 
 * -----------------------------------------------------------------------------
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include <propertytableInternal.h>
#include <allocation_include.h>

static PropertytableStatus convertHashtableStatus(HashtableStatus status);
static int isKeyDataFormat(char *string);
static int isSetDataFormat(char *string);

static Property_file_work_table * Property_file_create_work_struct(void);
static void Property_file_free_work_struct(Property_file_work_table * work);
static Property_file_work_table * Property_work_struct_setType(Property_file_work_table *work,Property_file_Token_Type type);
static Property_file_work_table * Property_work_struct_setChar(Property_file_work_table *work, int c);
static Property_file_lex_table * Property_file_link_work_struct(Property_file_lex_table *lex,Property_file_work_table *work);
static int _unGet_Charactor(Property_file_lex_table *lex,int c);
static int _get_Charactor(FILE *input,Property_file_lex_table *lex);
static Property_file_Parse_Status property_file_lexical_key(FILE *input,Property_file_lex_table *lex);
static Property_file_Parse_Status property_file_lexical_equal(FILE *input,Property_file_lex_table *lex);
static Property_file_Parse_Status property_file_lexical_data(FILE *input,Property_file_lex_table *lex);
static Property_file_Parse_Status property_file_lexical_create_line(Property_file_lex_table *lex,FILE *input,Property_file_work_table **return_key);
static Property_file_Parse_Status property_file_lexical(Property_file_lex_table **return_lex,FILE *input);
static void property_file_free_token(Property_file_lex_table *lex);
static Property_file_Parse_Status property_file_assembly(Propertytable *property,Property_file_lex_table *lex,Property_file_work_table *work);
static Property_file_Parse_Status property_file_all_assembly(Propertytable *property,Property_file_lex_table *lex);
static Property_file_Parse_Status properties_file_parse(Propertytable *property,FILE *input);
static void property_file_lexical_commentdel(Property_file_lex_table *lex,FILE *input);



static PropertytableStatus convertHashtableStatus(HashtableStatus status){
	PropertytableStatus ret;
	switch(status){
		case HASHTABLE_CREATE_SUCCESS:
			ret=PROPERTYTABLE_CREATE_SUCCESS;
			break;
		case HASHTABLE_FREE_SUCCESS:
			ret=PROPERTYTABLE_FREE_SUCCESS;
			break;
		case HASHTABLE_ADD_OBJECT_SUCCESS:
			ret=PROPERTYTABLE_ADD_OBJECT_SUCCESS;
			break;
		case HASHTABLE_PUT_OBJECT_SUCCESS:
			ret=PROPERTYTABLE_PUT_OBJECT_SUCCESS;
			break;
		case HASHTABLE_REMOVE_OBJECT_SUCCESS:
			ret=PROPERTYTABLE_REMOVE_OBJECT_SUCCESS;
			break;
		case HASHTABLE_FOUND_DATA:
			ret=PROPERTYTABLE_FOUND_DATA;
			break;
		case HASHTABLE_NOT_FOUND_DATA:
			ret=PROPERTYTABLE_NOT_FOUND_DATA;
			break;
		case HASHTABLE_PRINT_SUCCESS:
			ret=PROPERTYTABLE_PRINT_SUCCESS;
			break;
		case HASHTABLE_CREATE_LIST_SUCCESS:
			ret=PROPERTYTABLE_CREATE_LIST_SUCCESS;
			break;
		case HASHTABLE_EXCEPTION:
			ret=PROPERTYTABLE_EXCEPTION;
			break;
		case HASHTABLE_CREATE_EXCEPTION:
			ret=PROPERTYTABLE_CREATE_EXCEPTION;
			break;
		case HASHTABLE_FREE_EXCEPTION:
			ret=PROPERTYTABLE_FREE_EXCEPTION;
			break;
		case HASHTABLE_SEARCH_EXCEPTION:
			ret=PROPERTYTABLE_SEARCH_EXCEPTION;
			break;
		case HASHTABLE_ADD_OBJECT_EXCEPTION:
			ret=PROPERTYTABLE_ADD_OBJECT_EXCEPTION;
			break;
		case HASHTABLE_PUT_OBJECT_EXCEPTION:
			ret=PROPERTYTABLE_PUT_OBJECT_EXCEPTION;
			break;
		case HASHTABLE_REMOVE_OBJECT_EXCEPTION:
			ret=PROPERTYTABLE_REMOVE_OBJECT_EXCEPTION;
			break;
		case HASHTABLE_PRINT_EXCEPTION:
			ret=PROPERTYTABLE_PRINT_EXCEPTION;
			break;
		case HASHTABLE_CREATE_LIST_EXCEPTION:
			ret=PROPERTYTABLE_CREATE_LIST_EXCEPTION;
			break;
		case HASHTABLE_INDEX_OUT_OF_BOUNDS_EXCEPTION:
			ret=PROPERTYTABLE_INDEX_OUT_OF_BOUNDS_EXCEPTION;
			break;
		case HASHTABLE_OUT_OF_MEMORY:
			ret=PROPERTYTABLE_OUT_OF_MEMORY;
			break;
		default:
			ret=PROPERTYTABLE_STATUS_CONVERT_EXCEPTION;
			break;
	}
	return ret;
}

/* �L�[�́u�擪�����ɃA���_�[�o�[���p�����s���I�h�A�c�蕶���ɃA���_�[�o�[���p�������s���I�h�v�ȊO�F�߂��Ȃ��B */

static int isKeyDataFormat(char *string){

	if(
		!(string && *string) || 
		!((*string=='.') || (*string=='_') || isalpha(*string))
	){
		return 0;/* �L�[�f�[�^�Ƃ��Đ������Ȃ� */
	}

	while(*string){
		if(!((*string=='.') || (*string=='_') || isalnum(*string))){
			return 0;/* �L�[�f�[�^�Ƃ��Đ������Ȃ� */
		}
		string++;
	}
	return 1;/* �L�[�f�[�^�Ƃ��Đ����� */
}

/* �f�[�^�Ƀ_�u���N�I�[�e�[�V�����͔F�߂��Ȃ��B */

static int isSetDataFormat(char *string){

	if(
		!(string) || 
		strchr(string,'\"')
	){
		return 0;/* �L�[�f�[�^�Ƃ��Đ������Ȃ� */
	}


	return 1;/* �L�[�f�[�^�Ƃ��Đ����� */

}

/**
 * 
 * �v���p�e�B�e�[�u�����쐬����B
 * 
 * @param ret �v���p�e�B�e�[�u���̃|�C���^�̃|�C���^�i�v���p�e�B�e�[�u���̃|�C���^��Ԃ��j
 * @param size �v���p�e�B�e�[�u���̃n�b�V���T�C�Y
 * @return �v���p�e�B�e�[�u���C�u�����X�e�[�^�X(�v���p�e�B�e�[�u���쐬����)
 * 
 */
PropertytableStatus createPropertytable(
Propertytable **ret,
unsigned long size
){
	Hashtable *hobject=(Hashtable *)NULL;
	Propertytable *object;
	PropertytableStatus rets;
	if(ret==(Propertytable **)NULL){
		return PROPERTYTABLE_CREATE_EXCEPTION;
	}

	rets=convertHashtableStatus(createHashtable(&hobject,size,NULL));
	if(rets==PROPERTYTABLE_CREATE_SUCCESS && hobject!=(Hashtable *)NULL){
		if((Propertytable *)NULL==(object=(Propertytable *)Malloc(sizeof(Propertytable)))){
			Free(hobject);
			return PROPERTYTABLE_OUT_OF_MEMORY;
		}
		object->table=hobject;
		*ret=object;
		return rets;
	}
	return PROPERTYTABLE_CREATE_EXCEPTION;
}

/**
 * 
 * �v���p�e�B�e�[�u�����������B
 * 
 * @param property �v���p�e�B�e�[�u���̃|�C���^
 * @return �v���p�e�B�e�[�u�����C�u�����X�e�[�^�X(�v���p�e�B�e�[�u���������)
 * 
 */
PropertytableStatus freePropertytable(Propertytable *property){
	PropertytableStatus ret;
	if(property==(Propertytable *)NULL){
		return PROPERTYTABLE_FREE_EXCEPTION;
	}
	ret=convertHashtableStatus(freeHashtable(property->table));
	Free(property);
	return ret;
}


/**
 * 
 * �v�f�L�[���w�肵�A�v���p�e�B�e�[�u������ړI�̕�������擾����B
 * 
 * @param property �v���p�e�B�e�[�u���̃|�C���^
 * @param indexstring �v�f�L�[������
 * @param ret �ړI������
 * @return �v���p�e�B�e�[�u�����C�u�����X�e�[�^�X(�ړI�̕�����擾����)
 * 
 */
PropertytableStatus searchPropertytable(Propertytable *property,char *indexstring, char **ret){
	if(property==(Propertytable *)NULL || indexstring==(char *)NULL || ret==(char **)NULL){
		return PROPERTYTABLE_SEARCH_EXCEPTION;
	}
	return convertHashtableStatus(searchHashtable(property->table, indexstring, (void **)ret));
}



/**
 * 
 * �v���p�e�B�e�[�u���ɕ�����v�f���R�s�[���Ēǉ�����i�ێ�����镶����̈�͕ʓr�m�ۂ����j�B
 * 
 * @param property �v���p�e�B�e�[�u���̃|�C���^
 * @param indexstring �v�f�L�[������
 * @param object �ǉ�������i���̂̓R�s�[�����j
 * @return �v���p�e�B�e�[�u�����C�u�����X�e�[�^�X(������ǉ�����)
 * 
 */
PropertytableStatus addPropertytable(Propertytable *property,char *indexstring,char *object){

	char *c;
	PropertytableStatus status;
	if(property==(Propertytable *)NULL || indexstring==(char *)NULL || object==(char *)NULL){
		return PROPERTYTABLE_ADD_OBJECT_EXCEPTION;

	}else if(!isKeyDataFormat(indexstring)){
		return PROPERTYTABLE_KEY_DATA_EXCEPTION;
	}else if(!isSetDataFormat(object)){
		return PROPERTYTABLE_DATA_FORMAT_EXCEPTION;
	}else if((char *)NULL==(c=(char *)Malloc(strlen(object) + 1))){
		return PROPERTYTABLE_OUT_OF_MEMORY;
	}
	strcpy(c,object);
	status=convertHashtableStatus(addHashtable(property->table,indexstring,c,Free_p));
	if(status>=PROPERTYTABLE_EXCEPTION)Free(c);
	return status;
}



/**
 * 
 * �v���p�e�B�e�[�u���ɕ�����v�f���R�s�[���Đݒ肷��B
 * �i�ێ�����镶����̈�͕ʓr�m�ۂ���A�����瑶�݂��镶����̈�͉�������j
 * 
 * @param property �v���p�e�B�e�[�u���̃|�C���^
 * @param indexstring �v�f�L�[������
 * @param object �ǉ�������i���̂̓R�s�[�����j
 * @return �v���p�e�B�e�[�u�����C�u�����X�e�[�^�X(������ݒ茋��)
 * 
 */
PropertytableStatus putPropertytable(Propertytable *property,char *indexstring,char *object){
	char *c;
	PropertytableStatus status;
	if(property==(Propertytable *)NULL || indexstring==(char *)NULL || object==(char *)NULL){
		return PROPERTYTABLE_PUT_OBJECT_EXCEPTION;
	}else if(!isKeyDataFormat(indexstring)){
		return PROPERTYTABLE_KEY_DATA_EXCEPTION;
	}else if(!isSetDataFormat(object)){
		return PROPERTYTABLE_DATA_FORMAT_EXCEPTION;
	}else if((char *)NULL==(c=(char *)Malloc(strlen(object) + 1))){
		return PROPERTYTABLE_OUT_OF_MEMORY;
	}
	strcpy(c,object);
	status=convertHashtableStatus(putHashtable(property->table,indexstring,c,Free_p));
	if(status>=PROPERTYTABLE_EXCEPTION)Free(c);
	return status;
}



/**
 * 
 * �v���p�e�B�e�[�u���ɐݒ肳��Ă��镶����v�f���폜����B
 * �i������v�f�͉�������j
 * 
 * @param property �v���p�e�B�e�[�u���̃|�C���^
 * @param indexstring �v�f�L�[������
 * @return �v���p�e�B�e�[�u�����C�u�����X�e�[�^�X(������폜����)
 * 
 */
PropertytableStatus removePropertytable(Propertytable *property,char *indexstring){
	if(property==(Propertytable *)NULL || indexstring==(char *)NULL){
		return PROPERTYTABLE_REMOVE_OBJECT_EXCEPTION;
	}else if(!isKeyDataFormat(indexstring)){
		return PROPERTYTABLE_KEY_DATA_EXCEPTION;
	}
	return convertHashtableStatus(removeHashtable(property->table,indexstring));
}



/**
 * 
 * �v���p�e�B�e�[�u���̗̈�T�C�Y�i�v�f���ł͂Ȃ��j���擾����B
 * 
 * @param property �v���p�e�B�e�[�u���̃|�C���^
 * @return �v���p�e�B�e�[�u���̗̈�T�C�Y
 * 
 */
unsigned long sizeOfPropertytable(Propertytable *property){
	if(property==(Propertytable *)NULL){
		return PROPERTYTABLE_NULL_POINTER_EXCEPTION;
	}
	/* �n�b�V���f�[�^�̈�̐���Ԃ� */
	return sizeOfHashtable(property->table);
}


/**
 * 
 * �v���p�e�B�e�[�u���̃f�[�^�v�f�����擾����B
 * 
 * @param property �v���p�e�B���e�[�u���̃|�C���^
 * @return �v���p�e�B�e�[�u���̃f�[�^�v�f��
 * 
 */
unsigned long dataCountPropertytable(Propertytable *property){
	if(property==(Propertytable *)NULL){
		return PROPERTYTABLE_NULL_POINTER_EXCEPTION;
	}
	/* �n�b�V���Ɋi�[���ꂽ�I�u�W�F�N�g�̐���Ԃ� */
	return dataCountHashtable(property->table);
}

/**
 * 
 * �v���p�e�B�e�[�u���̃L�[��������t�@�C���|�C���^�̃t�@�C���ɏo�͂���B
 * 
 * @param property �v���p�e�B�e�[�u���̃|�C���^
 * @param output �o�͐�t�@�C���|�C���^
 * @return �v���p�e�B�e�[�u�����C�u�����X�e�[�^�X(�L�[������o�͌���)
 * 
 */
PropertytableStatus printPropertytable(Propertytable *property,FILE *output){
	if(property==(Propertytable *)NULL || output==(FILE *)NULL){
		return PROPERTYTABLE_PRINT_EXCEPTION;
	}
	return convertHashtableStatus(printHashtable(property->table,output));
}




















/*
static Property_file_Parse_Status printMessagePropertyParseStatus(Property_file_Parse_Status status){

	switch(status){
		case PROPERTYTABLE_PARSE_STATUS_PARSE_ASSEMBLE_SUCCESS:
			fprintf(stderr,"PROPERTYTABLE_PARSE_STATUS_PARSE_ASSEMBLE_SUCCESS\n");
			break;
		case PROPERTYTABLE_PARSE_STATUS_PARSE_CONTINUE:
			fprintf(stderr,"PROPERTYTABLE_PARSE_STATUS_PARSE_CONTINUE\n");
			break;
		case PROPERTYTABLE_PARSE_STATUS_PARSE_SUCCESS:
			fprintf(stderr,"PROPERTYTABLE_PARSE_STATUS_PARSE_SUCCESS\n");
			break;
		case PROPERTYTABLE_PARSE_STATUS_EXCEPTION:
			fprintf(stderr,"PROPERTYTABLE_PARSE_STATUS_EXCEPTION\n");
			break;
		case PROPERTYTABLE_PARSE_STATUS_PARSE_EXCEPTION:
			fprintf(stderr,"PROPERTYTABLE_PARSE_STATUS_PARSE_EXCEPTION\n");
			break;
		case PROPERTYTABLE_PARSE_STATUS_PARSE_KEY_EXCEPTION:
			fprintf(stderr,"PROPERTYTABLE_PARSE_STATUS_PARSE_KEY_EXCEPTION\n");
			break;
		case PROPERTYTABLE_PARSE_STATUS_PARSE_EQUAL_EXCEPTION:
			fprintf(stderr,"PROPERTYTABLE_PARSE_STATUS_PARSE_EQUAL_EXCEPTION\n");
			break;
		case PROPERTYTABLE_PARSE_STATUS_PARSE_DATA_EXCEPTION:
			fprintf(stderr,"PROPERTYTABLE_PARSE_STATUS_PARSE_DATA_EXCEPTION\n");
			break;
		case PROPERTYTABLE_PARSE_STATUS_PARSE_ASSEMBLE_EXCEPTION:
			fprintf(stderr,"PROPERTYTABLE_PARSE_STATUS_PARSE_ASSEMBLE_EXCEPTION\n");
			break;
		case PROPERTYTABLE_PARSE_STATUS_OUT_OF_MEMORY:
			fprintf(stderr,"PROPERTYTABLE_PARSE_STATUS_OUT_OF_MEMORY\n");
			break;
		default:
			fprintf(stderr,"PROPERTYTABLE_PARSE_STATUS_ERROR\n");
			break;
	}
	return status;
}
*/
/*
static void printProperty_file_work_table_List(Property_file_lex_table *lex){
	Property_file_work_table *now;
	printf("printProperty_file_work_table_List\n");
	for(now=lex->start;now;now=now->next){
		switch(now->type){
			case PROPERTYTABLE_PARSE_TOKEN_ITEM_NONE:
				printf("PROPERTYTABLE_PARSE_TOKEN_ITEM_NONE\n");
				break;
			case PROPERTYTABLE_PARSE_TOKEN_ITEM_IS_KEY:
				printf("PROPERTYTABLE_PARSE_TOKEN_ITEM_IS_KEY\n");
				break;
			case PROPERTYTABLE_PARSE_TOKEN_ITEM_IS_EQUAL:
				printf("PROPERTYTABLE_PARSE_TOKEN_ITEM_IS_EQUAL\n");
				break;
			case PROPERTYTABLE_PARSE_TOKEN_ITEM_IS_DATA:
				printf("PROPERTYTABLE_PARSE_TOKEN_ITEM_IS_DATA\n");
				break;
			case PROPERTYTABLE_PARSE_TOKEN_ITEM_IS_FEED:
				printf("PROPERTYTABLE_PARSE_TOKEN_ITEM_IS_FEED\n");
				break;
		}
	}
}
*/





static Property_file_work_table *Property_file_create_work_struct(void){
	Property_file_work_table *work;
/* fprintf(stderr,"%s\n","Property_file_create_work_struct"); */
	work=(Property_file_work_table *)Malloc(sizeof(Property_file_work_table));
	if(!work){
		return work;
	}

	work->next=(Property_file_work_table * )NULL;
	work->datasize=0;
	work->str=(char *)NULL;
	work->type=PROPERTYTABLE_PARSE_TOKEN_ITEM_NONE;
/* fprintf(stderr,"%s\n","Property_file_create_work_struct end"); */
	return work;
}

static void Property_file_free_work_struct(Property_file_work_table * work){
/* fprintf(stderr,"%s\n","Property_file_free_work_struct"); */
	if(!work){
		return;
	}
	if(work->str){
		Free(work->str);
	}
	Free(work);
/* fprintf(stderr,"%s\n","Property_file_free_work_struct end"); */
}

static Property_file_work_table *Property_work_struct_setType(Property_file_work_table *work,Property_file_Token_Type type){
/* fprintf(stderr,"%s\n","Property_work_struct_setType"); */
	work->type=type;
/* fprintf(stderr,"%s\n","Property_work_struct_setType end"); */
	return work;
}


static Property_file_work_table *Property_work_struct_setChar(Property_file_work_table *work, int c){
	char *buf;
	unsigned long len;
/* fprintf(stderr,"%s\n","Property_work_struct_setChar"); */
	if((work->str==(char *)NULL)){
		if((buf=(char *)Malloc(__PROPERTY_WORK_TABLE_UNIT_DATA_SIZE + 1))==(char *)NULL){
			return (Property_file_work_table *)NULL;
		}
		work->datasize=__PROPERTY_WORK_TABLE_UNIT_DATA_SIZE + 1;
		work->str=buf;
		work->str[0]='\0';
	}else if(work->datasize<=(unsigned long)(strlen(work->str) + 2)){
		buf=work->str;
		if((buf=(char *)Realloc(buf,(work->datasize+__PROPERTY_WORK_TABLE_UNIT_DATA_SIZE + 1)))==(char *)NULL){
			return (Property_file_work_table *)NULL;
		}
		work->datasize+=__PROPERTY_WORK_TABLE_UNIT_DATA_SIZE + 1;
		work->str=buf;
	}
	len=strlen(work->str);
	work->str[len]=(char)c;
	work->str[len+1]='\0';
/* fprintf(stderr,"work->str=%s\n",work->str); */
/* fprintf(stderr,"%s\n","Property_work_struct_setChar end"); */
	return work;
}

static Property_file_lex_table *Property_file_link_work_struct(Property_file_lex_table *lex,Property_file_work_table *work){
/* fprintf(stderr,"%s\n","Property_file_link_work_struct"); */
	lex->end=lex->end->next=work;
	
/* fprintf(stderr,"%s:%d\n","Property_file_link_work_struct end",work->type); */
	return lex;
}

static int _unGet_Charactor(Property_file_lex_table *lex,int c){
/* fprintf(stderr,"%s\n","_unGet_Charactor"); */
	if(lex->pushBackChar!=-1){
/* fprintf(stderr,"%s\n","_unGet_Charactor end"); */
		return 0;
	}else{
		lex->pushBackChar=c;
/* fprintf(stderr,"%s\n","_unGet_Charactor end"); */
		return 1;
	}
}

static int _get_Charactor(FILE *input,Property_file_lex_table *lex){
	int c;
/* fprintf(stderr,"%s\n","_get_Charactor"); */
	if(lex->pushBackChar!=-1){
		c=lex->pushBackChar;
		lex->pushBackChar=-1;
/* fprintf(stderr,"%s\n","_get_Charactor end"); */
		return c;
	}else{
/* fprintf(stderr,"%s\n","_get_Charactor end"); */
		return fgetc(input);
	}
}




static Property_file_Parse_Status property_file_lexical_key(FILE *input,Property_file_lex_table *lex){
	Property_file_work_table * work;
	int c,okflg=0;
	Property_file_Parse_Status rets;
/* fprintf(stderr,"%s\n","property_file_lexical_key"); */

	if((work=Property_file_create_work_struct())==(Property_file_work_table *)NULL){
	/* 	return printMessagePropertyParseStatus(PROPERTYTABLE_PARSE_STATUS_OUT_OF_MEMORY); */
		return PROPERTYTABLE_PARSE_STATUS_OUT_OF_MEMORY;
	}

	c=_get_Charactor(input,lex);
	if(isspace(c)){
		while((c=_get_Charactor(input,lex))!=EOF && isspace(c));
	}

	if(c=='.' || c=='_' || isalpha(c)){
		okflg=1;
		if(Property_work_struct_setChar(work,c)==(Property_file_work_table *)NULL){
			rets=PROPERTYTABLE_PARSE_STATUS_OUT_OF_MEMORY;
			goto ERROR_END;
		}

		while((c=_get_Charactor(input,lex))!=EOF){

			if(isspace(c)){
				break;
			}else if(isalpha(c) || c=='.' || c=='_'){
				okflg=1;
				if(Property_work_struct_setChar(work,c)==(Property_file_work_table *)NULL){
					rets=PROPERTYTABLE_PARSE_STATUS_OUT_OF_MEMORY;
					goto ERROR_END;
				}
			}else if(isdigit(c) && okflg){
				if(Property_work_struct_setChar(work,c)==(Property_file_work_table *)NULL){
					rets=PROPERTYTABLE_PARSE_STATUS_OUT_OF_MEMORY;
					goto ERROR_END;
				}
			}else if(c=='='){
				if(!_unGet_Charactor(lex,c)){
					rets=PROPERTYTABLE_PARSE_STATUS_PARSE_KEY_EXCEPTION;
					goto ERROR_END;
				}
				break;
			}else{
				rets=PROPERTYTABLE_PARSE_STATUS_PARSE_KEY_EXCEPTION;
				goto ERROR_END;
			}
		}
	}

	if(c==EOF){
		Property_work_struct_setType(work,PROPERTYTABLE_PARSE_TOKEN_ITEM_IS_FEED);
		if(!_unGet_Charactor(lex,c)){
			rets=PROPERTYTABLE_PARSE_STATUS_PARSE_KEY_EXCEPTION;
			goto ERROR_END;
		}
		rets=PROPERTYTABLE_PARSE_STATUS_PARSE_SUCCESS;
	}else{
		Property_work_struct_setType(work,PROPERTYTABLE_PARSE_TOKEN_ITEM_IS_KEY);
		if(!okflg){
			rets=PROPERTYTABLE_PARSE_STATUS_PARSE_KEY_EXCEPTION;
			goto ERROR_END;
		}
		rets=PROPERTYTABLE_PARSE_STATUS_PARSE_CONTINUE;
	}

	if(!lex->start){
		lex->start=lex->end=work;
/* fprintf(stderr,"%s:%d\n","work->type",work->type); */
	}else{
		Property_file_link_work_struct(lex,work);
	}
/* fprintf(stderr,"%s\n","property_file_lexical_key end"); */
/* 	return  printMessagePropertyParseStatus(rets); */
	return rets;

ERROR_END:
	Property_file_free_work_struct(work);
/* fprintf(stderr,"%s\n","property_file_lexical_key end"); */
/* 	return  printMessagePropertyParseStatus(rets); */
	return rets;
}



static Property_file_Parse_Status property_file_lexical_equal(FILE *input,Property_file_lex_table *lex){
	Property_file_work_table * work;
	int c;
/* fprintf(stderr,"%s\n","property_file_lexical_equal"); */
	c=_get_Charactor(input,lex);
	if(isspace(c)){
		if(!_unGet_Charactor(lex,c)){
			return PROPERTYTABLE_PARSE_STATUS_PARSE_EQUAL_EXCEPTION;
		}
		while((c=_get_Charactor(input, lex))!=EOF && isspace(c)){
			if(c=='\n'){
				/* return printMessagePropertyParseStatus(PROPERTYTABLE_PARSE_STATUS_PARSE_EQUAL_EXCEPTION); */
				return PROPERTYTABLE_PARSE_STATUS_PARSE_EQUAL_EXCEPTION;
			}
		}

		if(c==EOF){
			/* return printMessagePropertyParseStatus(PROPERTYTABLE_PARSE_STATUS_PARSE_EQUAL_EXCEPTION); */
			return PROPERTYTABLE_PARSE_STATUS_PARSE_EQUAL_EXCEPTION;
		}
	}

	if(c!='='){
		/* return printMessagePropertyParseStatus(PROPERTYTABLE_PARSE_STATUS_PARSE_EQUAL_EXCEPTION); */
		return PROPERTYTABLE_PARSE_STATUS_PARSE_EQUAL_EXCEPTION;
	}
	if((work=Property_file_create_work_struct())==(Property_file_work_table *)NULL){
		/* return printMessagePropertyParseStatus(PROPERTYTABLE_PARSE_STATUS_OUT_OF_MEMORY); */
		return PROPERTYTABLE_PARSE_STATUS_OUT_OF_MEMORY;
	}

	Property_work_struct_setType(work,PROPERTYTABLE_PARSE_TOKEN_ITEM_IS_EQUAL);
	Property_file_link_work_struct(lex, work);
/* fprintf(stderr,"%s\n","property_file_lexical_equal end"); */
/* 	return  printMessagePropertyParseStatus(PROPERTYTABLE_PARSE_STATUS_PARSE_CONTINUE); */
	return PROPERTYTABLE_PARSE_STATUS_PARSE_CONTINUE;
}



static Property_file_Parse_Status property_file_lexical_data(FILE *input,Property_file_lex_table *lex){
	Property_file_work_table * work;
	int c,strflg=0,okflg=0;

	Property_file_Parse_Status rets=PROPERTYTABLE_PARSE_STATUS_PARSE_SUCCESS;

/* fprintf(stderr,"%s\n","property_file_lexical_data"); */
	if((work=Property_file_create_work_struct())==(Property_file_work_table *)NULL){
/* fprintf(stderr,"%s\n","property_file_lexical_data end"); */
		/* return printMessagePropertyParseStatus(PROPERTYTABLE_PARSE_STATUS_OUT_OF_MEMORY); */
		return PROPERTYTABLE_PARSE_STATUS_OUT_OF_MEMORY;
	}

	c=_get_Charactor(input,lex);

	if(isspace(c)){
		if(!_unGet_Charactor(lex,c)){
			rets=PROPERTYTABLE_PARSE_STATUS_PARSE_DATA_EXCEPTION;
			goto ERROR_END;
		}
		while((c=_get_Charactor(input,lex))!=EOF && isspace(c) && c!='\n');
	}

	if(c!=EOF){

		if(!_unGet_Charactor(lex,c)){
			rets=PROPERTYTABLE_PARSE_STATUS_PARSE_DATA_EXCEPTION;
			goto ERROR_END;
		}

		while((c=_get_Charactor(input,lex))!=EOF){

			if(!strflg){
				if(c=='\n'){
					if(!okflg){
						okflg=1;
						if(Property_work_struct_setChar(work, 0x00)==(Property_file_work_table *)NULL){
							rets=PROPERTYTABLE_PARSE_STATUS_OUT_OF_MEMORY;
							goto ERROR_END;
						}
					}
					break;
				}else if(isspace(c)){
					if(okflg){
						while((c=_get_Charactor(input,lex))!=EOF){
							if(c=='\n' || c==EOF){
								break;
							}else if(isspace(c)){
								continue;
							}else{
								rets= PROPERTYTABLE_PARSE_STATUS_PARSE_DATA_EXCEPTION;
								goto ERROR_END;
							}
						}
						break;
					}
				}else if(c=='\"'){
					if(okflg){
						rets= PROPERTYTABLE_PARSE_STATUS_PARSE_DATA_EXCEPTION;
						goto ERROR_END;
					}
					strflg=1;
				}else if(c=='='){
					rets= PROPERTYTABLE_PARSE_STATUS_PARSE_DATA_EXCEPTION;
					goto ERROR_END;

				}else{
					okflg=1;
					if(Property_work_struct_setChar(work,c)==(Property_file_work_table *)NULL){
						rets=PROPERTYTABLE_PARSE_STATUS_OUT_OF_MEMORY;
						goto ERROR_END;
					}
				}

			}else{
				if(c=='\"'){
					strflg=0;
					okflg=1;
					while((c=_get_Charactor(input,lex))!=EOF){
						if(c=='\n' || c==EOF){
							break;
						}else if(isspace(c)){
							continue;
						}else{
							rets= PROPERTYTABLE_PARSE_STATUS_PARSE_DATA_EXCEPTION;
							goto ERROR_END;
						}
					}
					break;
				}else{
					okflg=1;
					if(Property_work_struct_setChar(work,c)==(Property_file_work_table *)NULL){
						rets=PROPERTYTABLE_PARSE_STATUS_OUT_OF_MEMORY;
						goto ERROR_END;
					}
				}
			}
		}
	}
	if(c==EOF){
		if(!_unGet_Charactor(lex,c)){
			rets=PROPERTYTABLE_PARSE_STATUS_PARSE_DATA_EXCEPTION;
			goto ERROR_END;
		}
	}

	if(!okflg || strflg){
		rets=PROPERTYTABLE_PARSE_STATUS_PARSE_DATA_EXCEPTION;
		goto ERROR_END;
	}

	Property_work_struct_setType(work,PROPERTYTABLE_PARSE_TOKEN_ITEM_IS_DATA);
	Property_file_link_work_struct(lex,work);
/* fprintf(stderr,"%s\n","property_file_lexical_data end"); */
	/* return  printMessagePropertyParseStatus(rets); */
	return rets;

ERROR_END:
	Property_file_free_work_struct(work);
/* fprintf(stderr,"%s\n","property_file_lexical_data end"); */
	/* return  printMessagePropertyParseStatus(rets); */
	return rets;
}

static void property_file_lexical_commentdel(Property_file_lex_table *lex,FILE *input){
	int c;
	while((c=_get_Charactor(input,lex))!=EOF){
		if(c=='\n'){
			continue;
		}else if(isspace(c)){
		}else if(c=='#'){
			while((c=_get_Charactor(input,lex))!=EOF && c!='\n');
			_unGet_Charactor(lex,c);
		}else{
			_unGet_Charactor(lex,c);
			break;
		}
	}

}

static Property_file_Parse_Status property_file_lexical_create_line(Property_file_lex_table *lex,FILE *input,Property_file_work_table **return_key){
	Property_file_Parse_Status status;
/* fprintf(stderr,"%s\n","property_file_lexical_create_line"); */

	property_file_lexical_commentdel(lex,input);

	if((status=property_file_lexical_key(input,lex))==PROPERTYTABLE_PARSE_STATUS_PARSE_SUCCESS){

		status=PROPERTYTABLE_PARSE_STATUS_PARSE_SUCCESS;
		*return_key=lex->end;
	}else if(
		status<PROPERTYTABLE_PARSE_STATUS_EXCEPTION && 
		(status=property_file_lexical_equal(input,lex))<PROPERTYTABLE_PARSE_STATUS_EXCEPTION &&
		(status=property_file_lexical_data(input,lex))<PROPERTYTABLE_PARSE_STATUS_EXCEPTION
	){
		*return_key=lex->end;
		status=PROPERTYTABLE_PARSE_STATUS_PARSE_CONTINUE;
	}else{
		/* ��͎��s */
		status=PROPERTYTABLE_PARSE_STATUS_EXCEPTION;
	}
/* fprintf(stderr,"%s\n","property_file_lexical_create_line end"); */
	/* return  printMessagePropertyParseStatus(status); */
	return status;
}



static Property_file_Parse_Status property_file_lexical(Property_file_lex_table **return_lex,FILE *input){
	Property_file_lex_table *lex;
	Property_file_work_table *now;
	Property_file_Parse_Status status;
/* fprintf(stderr,"%s\n","property_file_lexical"); */
	lex=(Property_file_lex_table *)Malloc(sizeof(Property_file_lex_table));
	if(lex==(Property_file_lex_table *)NULL){
		return PROPERTYTABLE_PARSE_STATUS_OUT_OF_MEMORY;
	}
	lex->start=lex->end=(Property_file_work_table *)NULL;
	lex->pushBackChar=-1;
	lex->nowkey=(char *)NULL;
	while((status=property_file_lexical_create_line(lex,input,&now))==PROPERTYTABLE_PARSE_STATUS_PARSE_CONTINUE);
	if(status==PROPERTYTABLE_PARSE_STATUS_PARSE_SUCCESS){
		*return_lex=lex;
	} else {
		Free(lex);
	}
/* fprintf(stderr,"%s\n","property_file_lexical end"); */
	/* return  printMessagePropertyParseStatus(status); */
	return status;
}

static void property_file_free_token(Property_file_lex_table *lex){
	Property_file_work_table *now,*freebuf;
/* fprintf(stderr,"%s\n","property_file_free_token"); */
	for(now=lex->start;now;now=now->next,Property_file_free_work_struct(freebuf)){
		freebuf=now;
	}
	Free(lex);
/* fprintf(stderr,"%s\n","property_file_free_token end"); */
}

static Property_file_Parse_Status property_file_assembly(Propertytable *property,Property_file_lex_table *lex,Property_file_work_table *work){
	Property_file_Parse_Status status=PROPERTYTABLE_PARSE_STATUS_PARSE_ASSEMBLE_SUCCESS;
	char *setStr;
	setStr=work->str;
/* fprintf(stderr,"%s\n","property_file_assembly"); */
	if(!setStr)setStr=(char *)"";

	switch(work->type){
		case PROPERTYTABLE_PARSE_TOKEN_ITEM_IS_KEY:
/* fprintf(stderr,"%s\n","PROPERTYTABLE_PARSE_TOKEN_ITEM_IS_KEY"); */
			lex->nowkey=setStr;
			break;
		case PROPERTYTABLE_PARSE_TOKEN_ITEM_IS_EQUAL:
/* fprintf(stderr,"%s\n","PROPERTYTABLE_PARSE_TOKEN_ITEM_IS_EQUAL"); */
			if(lex->nowkey==(char *)NULL){
				status=PROPERTYTABLE_PARSE_STATUS_PARSE_ASSEMBLE_EXCEPTION;
			}
			break;
		case PROPERTYTABLE_PARSE_TOKEN_ITEM_IS_DATA:
/* fprintf(stderr,"%s\n","PROPERTYTABLE_PARSE_TOKEN_ITEM_IS_DATA"); */
			if(lex->nowkey==(char *)NULL){
				status=PROPERTYTABLE_PARSE_STATUS_PARSE_ASSEMBLE_EXCEPTION;
			}
			putPropertytable(property,lex->nowkey,setStr);
			lex->nowkey=(char *)NULL;
			break;
		case PROPERTYTABLE_PARSE_TOKEN_ITEM_IS_FEED:
/* fprintf(stderr,"%s\n","PROPERTYTABLE_PARSE_TOKEN_ITEM_IS_FEED"); */
			lex->nowkey=(char *)NULL;
			break;
		default:
			status=PROPERTYTABLE_PARSE_STATUS_PARSE_ASSEMBLE_EXCEPTION;
			break;
	}
/* fprintf(stderr,"%s\n","property_file_assembly end"); */
	/* return  printMessagePropertyParseStatus(status); */
	return status;
}

static Property_file_Parse_Status property_file_all_assembly(Propertytable *property,Property_file_lex_table *lex){
	Property_file_work_table *now;
	Property_file_Parse_Status status;
/* fprintf(stderr,"%s\n","property_file_all_assembly"); */
	for(now=lex->start;now;now=now->next){
		status=property_file_assembly(property,lex,now);
		if(status>=PROPERTYTABLE_PARSE_STATUS_EXCEPTION){
			/* �v���p�e�B�e�[�u�����N���A�����ɔ����� */
/* fprintf(stderr,"%s\n","property_file_all_assembly error"); */
/* fprintf(stderr,"%s\n","property_file_all_assembly end"); */
			/* return  printMessagePropertyParseStatus(status); */
			return status;
		}
	}
	/* printProperty_file_work_table_List(lex); */
/* fprintf(stderr,"%s\n","property_file_all_assembly end"); */
	/* return  printMessagePropertyParseStatus(PROPERTYTABLE_PARSE_STATUS_PARSE_ASSEMBLE_SUCCESS); */
	return PROPERTYTABLE_PARSE_STATUS_PARSE_ASSEMBLE_SUCCESS;
}

static Property_file_Parse_Status properties_file_parse(Propertytable *property,FILE *input){
	Property_file_lex_table *lex;
	Property_file_Parse_Status status;
/* fprintf(stderr,"%s\n","properties_file_parse"); */
	if((status=property_file_lexical(&lex,input))>=PROPERTYTABLE_PARSE_STATUS_EXCEPTION){
		/* return  printMessagePropertyParseStatus(status); */
		return  status;
	}
	status=property_file_all_assembly(property,lex);
	property_file_free_token(lex);
/* fprintf(stderr,"%s\n","properties_file_parse end"); */
	/* return  printMessagePropertyParseStatus(status); */
	return  status;
}







/**
 * 
 * �v���p�e�B�e�[�u���Ƀt�@�C������f�[�^�����[�h����B
 * �i�u�L�[=�f�[�^�v�Ƃ����`���̃f�[�^�����񂳂�Ă���t�@�C���`���̃t�@�C��������͂���j
 * 
 * ������e�[�u���ɑ��݂���f�[�^�͎c�����܂܁A�L�[���Ԃ���f�[�^�������㏑������B
 * �i�L�[���Ԃ������ꍇ�A���̃f�[�^�͉�������j
 * 
 * @param property �v���p�e�B�e�[�u���̃|�C���^
 * @param input ���͌��t�@�C���|�C���^
 * @return �v���p�e�B�e�[�u�����C�u�����X�e�[�^�X(�t�@�C�����[�h����)
 * 
 */
PropertytableStatus loadPropertytable(Propertytable *property,FILE *input){
/* fprintf(stderr,"%s\n","loadPropertytable"); */
	if(
		property==(Propertytable *)NULL || 
		input==(FILE *)NULL || 
		(properties_file_parse(property,input)>=PROPERTYTABLE_PARSE_STATUS_EXCEPTION)
	){
/* fprintf(stderr,"%s\n","loadPropertytable end"); */
		return PROPERTYTABLE_LOAD_PROPERTIES_EXCEPTION;
	}
/* fprintf(stderr,"%s\n","loadPropertytable end"); */
	return PROPERTYTABLE_LOAD_PROPERTIES_SUCCESS;

}


/**
 * 
 * �v���p�e�B�e�[�u���̃f�[�^���Ƀt�@�C���ɃZ�[�u����B
 * 
 * @param property �v���p�e�B�e�[�u���̃|�C���^
 * @param output �o�͐�t�@�C���|�C���^
 * @return �v���p�e�B�e�[�u�����C�u�����X�e�[�^�X(�t�@�C���Z�[�u����)
 * 
 */
PropertytableStatus savePropertytable(Propertytable *property,FILE *output){

	LinkedList *list=(LinkedList *)NULL;
	Iterator *ite=(Iterator *)NULL;
/* 	unsigned long l,size; */
	char *c,*retStr=(char *)NULL;

	PropertytableStatus ret= PROPERTYTABLE_SAVE_PROPERTIES_SUCCESS;
	if(
		property==(Propertytable *)NULL || 
		output==(FILE *)NULL ||
		getKeysHashtable(property->table,&list)!=HASHTABLE_CREATE_LIST_SUCCESS
	){
		return PROPERTYTABLE_SAVE_PROPERTIES_EXCEPTION;
	}
/*
	size = sizeOfLinkedList(list);
	for(l=0;l<size;l++){
		if((c=(char *)getObjectLinkedList(list,l))!=(char *)NULL){
			if(searchHashtable(property->table,c,(void **)&retStr)==HASHTABLE_FOUND_DATA){
				fprintf(output,"%s=\"%s\"\n",c,retStr);
			}
		}
	}
*/
	if(createIterator(list,&ite)==ITERATOR_CREATE_SUCCESS){
		while(hasMoreElementsIterator(ite)==ITERATOR_HAS_MORE_ELEMENTS_TRUE){
			if((c=(char *)nextElementIterator(ite))!=(char *)NULL){
				if(searchHashtable(property->table,c,(void **)&retStr)==HASHTABLE_FOUND_DATA){
					fprintf(output,"%s=\"%s\"\n",c,retStr);
				}
			}else{
				break;
			}
		}
		freeIterator(ite);
	}else{
		ret=PROPERTYTABLE_SAVE_PROPERTIES_EXCEPTION;
	}

	fflush(output);
	freeLinkedList(list);
	return ret;
}





/**
 * 
 * �v���p�e�B�e�[�u���̃L�[������̃��X�g���擾����B
 * 
 * @param property �v���p�e�B�e�[�u���̃|�C���^
 * @param ret �L�[�������v�f�Ƃ���A�����X�g�̃|�C���^�̃|�C���^�i�A�����X�g�̃|�C���^��Ԃ��j
 * @return �v���p�e�B�e�[�u�����C�u�����X�e�[�^�X(�L�[������̃��X�g�擾����)
 * 
 */
PropertytableStatus getKeysPropertytable(Propertytable *property,LinkedList **ret){
	return convertHashtableStatus(getKeysHashtable(property->table,ret));
}




/**
 * 
 * �v���p�e�B�e�[�u�����C�u�����X�e�[�^�X���b�Z�[�W���t�@�C���|�C���^�̃t�@�C���ɏo�͂���B
 * 
 * @param status �v���p�e�B�e�[�u�����C�u�����X�e�[�^�X
 * @param out �o�͐�t�@�C���|�C���^
 * 
 */
void printMessageStatusPropertytable(PropertytableStatus status,FILE *out){

	switch(status){
		case PROPERTYTABLE_CREATE_SUCCESS:
			fprintf(out,"PROPERTYTABLE_CREATE_SUCCESS\n");
			break;
		case PROPERTYTABLE_FREE_SUCCESS:
			fprintf(out,"PROPERTYTABLE_FREE_SUCCESS\n");
			break;
		case PROPERTYTABLE_ADD_OBJECT_SUCCESS:
			fprintf(out,"PROPERTYTABLE_ADD_OBJECT_SUCCESS\n");
			break;
		case PROPERTYTABLE_PUT_OBJECT_SUCCESS:
			fprintf(out,"PROPERTYTABLE_PUT_OBJECT_SUCCESS\n");
			break;
		case PROPERTYTABLE_REMOVE_OBJECT_SUCCESS:
			fprintf(out,"PROPERTYTABLE_REMOVE_OBJECT_SUCCESS\n");
			break;
		case PROPERTYTABLE_LOAD_PROPERTIES_SUCCESS:
			fprintf(out,"PROPERTYTABLE_LOAD_PROPERTIES_SUCCESS\n");
			break;
		case PROPERTYTABLE_SAVE_PROPERTIES_SUCCESS:
			fprintf(out,"PROPERTYTABLE_SAVE_PROPERTIES_SUCCESS\n");
			break;
		case PROPERTYTABLE_FOUND_DATA:
			fprintf(out,"PROPERTYTABLE_FOUND_DATA\n");
			break;
		case PROPERTYTABLE_NOT_FOUND_DATA:
			fprintf(out,"PROPERTYTABLE_NOT_FOUND_DATA\n");
			break;
		case PROPERTYTABLE_PRINT_SUCCESS:
			fprintf(out,"PROPERTYTABLE_PRINT_SUCCESS\n");
			break;
		case PROPERTYTABLE_CREATE_LIST_SUCCESS:
			fprintf(out,"PROPERTYTABLE_CREATE_LIST_SUCCESS\n");
			break;
		case PROPERTYTABLE_EXCEPTION:
			fprintf(out,"PROPERTYTABLE_EXCEPTION\n");
			break;
		case PROPERTYTABLE_CREATE_EXCEPTION:
			fprintf(out,"PROPERTYTABLE_CREATE_EXCEPTION\n");
			break;
		case PROPERTYTABLE_FREE_EXCEPTION:
			fprintf(out,"PROPERTYTABLE_FREE_EXCEPTION\n");
			break;
		case PROPERTYTABLE_NULL_POINTER_EXCEPTION:
			fprintf(out,"PROPERTYTABLE_NULL_POINTER_EXCEPTION\n");
			break;
		case PROPERTYTABLE_KEY_DATA_EXCEPTION:
			fprintf(out,"PROPERTYTABLE_KEY_DATA_EXCEPTION\n");
			break;
		case PROPERTYTABLE_DATA_FORMAT_EXCEPTION:
			fprintf(out,"PROPERTYTABLE_DATA_FORMAT_EXCEPTION\n");
			break;
		case PROPERTYTABLE_SEARCH_EXCEPTION:
			fprintf(out,"PROPERTYTABLE_SEARCH_EXCEPTION\n");
			break;
		case PROPERTYTABLE_ADD_OBJECT_EXCEPTION:
			fprintf(out,"PROPERTYTABLE_ADD_OBJECT_EXCEPTION\n");
			break;
		case PROPERTYTABLE_PUT_OBJECT_EXCEPTION:
			fprintf(out,"PROPERTYTABLE_PUT_OBJECT_EXCEPTION\n");
			break;
		case PROPERTYTABLE_REMOVE_OBJECT_EXCEPTION:
			fprintf(out,"PROPERTYTABLE_REMOVE_OBJECT_EXCEPTION\n");
			break;
		case PROPERTYTABLE_LOAD_PROPERTIES_EXCEPTION:
			fprintf(out,"PROPERTYTABLE_LOAD_PROPERTIES_EXCEPTION\n");
			break;
		case PROPERTYTABLE_SAVE_PROPERTIES_EXCEPTION:
			fprintf(out,"PROPERTYTABLE_SAVE_PROPERTIES_EXCEPTION\n");
			break;
		case PROPERTYTABLE_PRINT_EXCEPTION:
			fprintf(out,"PROPERTYTABLE_PRINT_EXCEPTION\n");
			break;
		case PROPERTYTABLE_CREATE_LIST_EXCEPTION:
			fprintf(out,"PROPERTYTABLE_CREATE_LIST_EXCEPTION\n");
			break;
		case PROPERTYTABLE_INDEX_OUT_OF_BOUNDS_EXCEPTION:
			fprintf(out,"PROPERTYTABLE_INDEX_OUT_OF_BOUNDS_EXCEPTION\n");
			break;
		case PROPERTYTABLE_OUT_OF_MEMORY:
			fprintf(out,"PROPERTYTABLE_OUT_OF_MEMORY\n");
			break;
		case PROPERTYTABLE_STATUS_CONVERT_EXCEPTION:
			fprintf(out,"PROPERTYTABLE_STATUS_CONVERT_EXCEPTION\n");
			break;
		default:
			fprintf(out,"PROPERTYTABLE_NOT_STATUS\n");
			break;
	}
}
